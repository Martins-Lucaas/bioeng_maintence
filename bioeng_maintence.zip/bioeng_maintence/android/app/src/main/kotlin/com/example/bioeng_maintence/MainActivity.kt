package com.example.bioeng_maintence

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
